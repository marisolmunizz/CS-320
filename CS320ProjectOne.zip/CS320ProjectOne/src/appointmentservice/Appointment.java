package appointmentservice; 
import java.util.Date; 
public class Appointment { 

	
// Appointment.java 
// Author: Marisol Muniz 
// Fields for appointment information 

 
private final String appointmentId; 
private Date appointmentDate; 
private String description; 

 

// Constructor saves the appointment when the information is correct 
public Appointment(String appointmentId, Date appointmentDate, String description) { 

	
// Checks appointment ID 
if (appointmentId == null || appointmentId.length() > 10) { 
throw new IllegalArgumentException("Invalid appointment ID"); 
} 
 

// Checks appointment date 
if (appointmentDate == null || appointmentDate.before(new Date())) { 
throw new IllegalArgumentException("Invalid appointment date"); 
} 

 
// Checks description 
if (description == null || description.length() > 50) { 
throw new IllegalArgumentException("Invalid description"); 
} 

 
// Saves information 
this.appointmentId = appointmentId; 
this.appointmentDate = appointmentDate; 
this.description = description; 
} 

 
// Shows appointment ID 
public String getAppointmentId() { 
return appointmentId; 
} 

 
// Shows appointment date 
public Date getAppointmentDate() { 
return appointmentDate; 
} 


// Shows description 
public String getDescription() { 
return description; 
} 
} 