package appointmentservice; 
import java.util.HashMap; 
import java.util.Map; 
public class AppointmentService { 


// AppointmentService.java 	
// Author: Marisol Muniz 
// Stores appointments 
private Map<String, Appointment> appointments = new HashMap<>(); 


// Adds appointment 
public void addAppointment(Appointment appointment) { 


// Checks for duplicate appointment ID 
if (appointments.containsKey(appointment.getAppointmentId())) { 
throw new IllegalArgumentException("Appointment ID already exists"); 
} 
appointments.put(appointment.getAppointmentId(), appointment); 
} 

 
// Deletes appointment 
public void deleteAppointment(String appointmentId) { 
appointments.remove(appointmentId); 
} 

 
// Shows appointment 
public Appointment getAppointment(String appointmentId) { 
return appointments.get(appointmentId); 
} 
} 