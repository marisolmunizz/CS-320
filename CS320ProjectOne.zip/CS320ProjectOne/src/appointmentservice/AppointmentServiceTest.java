package appointmentservice; 
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 
import java.util.Date; 
public class AppointmentServiceTest { 

 
// AppointmentServiceTest.java 
// Author: Marisol Muniz 
// Tests adding appointment 
@Test 
public void testAddAppointment() { 
AppointmentService service = new AppointmentService(); 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
Appointment appointment = 
new Appointment("12345", futureDate, "Doctor visit"); 
service.addAppointment(appointment); 
assertEquals(appointment, service.getAppointment("12345")); 
} 

 
// Tests duplicate appointment ID 
@Test 
public void testAddDuplicateAppointmentId() { 
AppointmentService service = new AppointmentService(); 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
Appointment appointment1 = 
new Appointment("12345", futureDate, "Doctor visit"); 
Appointment appointment2 = 
new Appointment("12345", futureDate, "Dentist visit"); 
service.addAppointment(appointment1); 
assertThrows(IllegalArgumentException.class, () -> { 
service.addAppointment(appointment2); 
}); 
} 

 
// Tests deleting appointment 
@Test 
public void testDeleteAppointment() { 
AppointmentService service = new AppointmentService(); 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
Appointment appointment = 
new Appointment("12345", futureDate, "Doctor visit"); 
service.addAppointment(appointment); 
service.deleteAppointment("12345"); 
assertNull(service.getAppointment("12345")); 
	} 
} 