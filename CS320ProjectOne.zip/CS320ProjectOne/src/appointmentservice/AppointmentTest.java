package appointmentservice; 
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 
import java.util.Date; 
public class AppointmentTest { 

// AppointmentTest.java
// Author: Marisol Muniz 
// Tests a valid appointment 
@Test 
public void testValidAppointment() { 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
Appointment appointment = 
new Appointment("12345", futureDate, "Doctor visit"); 
assertEquals("12345", appointment.getAppointmentId()); 
assertEquals(futureDate, appointment.getAppointmentDate()); 
assertEquals("Doctor visit", appointment.getDescription()); 
} 

 
// Tests empty appointment ID 
@Test 
public void testAppointmentIdNull() { 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment(null, futureDate, "Doctor visit"); 
}); 
} 


// Tests too long appointment ID 
@Test 
public void testAppointmentIdTooLong() { 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment("12345678901", futureDate, "Doctor visit"); 
}); 
} 

 
// Tests empty appointment date 
@Test 
public void testAppointmentDateNull() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment("12345", null, "Doctor visit"); 
}); 
} 


// Tests past appointment date 
@Test 
public void testAppointmentDateInPast() { 
Date pastDate = new Date(System.currentTimeMillis() - 86400000); 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment("12345", pastDate, "Doctor visit"); 
}); 
} 

 
// Tests empty description 
@Test 
public void testDescriptionNull() { 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment("12345", futureDate, null); 
}); 
} 

 
// Tests too long description 
@Test 
public void testDescriptionTooLong() { 
Date futureDate = new Date(System.currentTimeMillis() + 86400000); 
assertThrows(IllegalArgumentException.class, () -> { 
new Appointment( 
"12345", 
futureDate, 
"This description is definitely longer than fifty characters and should fail"); 
}); 
} 
} 