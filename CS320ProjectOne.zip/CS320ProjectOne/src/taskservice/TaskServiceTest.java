package taskservice;
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 


//TaskServiceTest.java 
//Author: Marisol Muniz  
//Tests the TaskService class. 
//Makes sure tasks can be added, deleted, and updated. 

public class TaskServiceTest { 


//adds task and checks it saved 
@Test 

public void testAddTask() { 

TaskService service = new TaskService(); 

Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

service.addTask(task); 

assertEquals(task, service.getTask("12345")); 

 } 


//tests duplicate task ID 
@Test 

public void testAddDuplicateTaskId() { 

TaskService service = new TaskService(); 



 Task task1 = new Task("12345", "Homework", "Finish CS 320 assignment"); 

Task task2 = new Task("12345", "Project", "Complete Project One"); 

service.addTask(task1); 

 assertThrows(IllegalArgumentException.class, () -> { 

 service.addTask(task2); 

 }); 

} 


//deletes task 
@Test 

 public void testDeleteTask() { 

TaskService service = new TaskService(); 
 Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

service.addTask(task); 

service.deleteTask("12345"); 

assertNull(service.getTask("12345")); 

} 


//tests deleting missing task 
@Test 

 public void testDeleteTaskNotFound() { 

 TaskService service = new TaskService(); 



 assertThrows(IllegalArgumentException.class, () -> { 

 service.deleteTask("99999"); 

}); 

} 


//updates task name 
@Test 

public void testUpdateTaskName() { 

TaskService service = new TaskService(); 

Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

service.addTask(task); 

service.updateName("12345", "Project"); 

assertEquals("Project", service.getTask("12345").getName()); 

} 


//updates task description 
@Test 

 public void testUpdateTaskDescription() { 

TaskService service = new TaskService(); 

Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

 service.addTask(task); 

service.updateDescription("12345", "Complete Project One"); 



 assertEquals("Complete Project One", 

service.getTask("12345").getDescription()); 

 } 


//tests updating missing task 
@Test 

public void testUpdateTaskNotFound() { 

TaskService service = new TaskService(); 

assertThrows(IllegalArgumentException.class, () -> { 

service.updateName("99999", "Project"); 
 }); 

 } 

} 