package taskservice;
import java.util.HashMap;
import java.util.Map;


//TaskService.java 
//Author: Marisol Muniz 
//Manages all tasks. 
//Can add, delete, and update tasks. 

public class TaskService {

// saves all tasks 
	private Map<String, Task> tasks = new HashMap<>();

	
// adds a new task 
public void addTask(Task task) { 

 
// makes sure task is not empty 
if (task == null) { 

throw new IllegalArgumentException("Task cannot be null"); 

} 


// gets task ID 
String taskId = task.getTaskId(); 

 
// checks if task ID is already used 
if (tasks.containsKey(taskId)) { 

throw new IllegalArgumentException("Task ID already exists"); 

} 

 
// saves task 
tasks.put(taskId, task); 

}



// deletes task 
public void deleteTask(String taskId) { 

 

// makes sure task exists 
if (!tasks.containsKey(taskId)) { 

throw new IllegalArgumentException("Task ID not found"); 

} 

 

// removes task 
tasks.remove(taskId); 

}

// updates task name 
public void updateName(String taskId, String name) { 



// finds task 
Task task = tasks.get(taskId); 

 
// makes sure task exists 
if (task == null) { 

throw new IllegalArgumentException("Task ID not found"); 

} 

 
// saves updated name 
task.setName(name); 

}

// updates task description 
public void updateDescription(String taskId, String description) {

// finds task 
Task task = tasks.get(taskId);

// makes sure task exists 
if (task == null) {
throw new IllegalArgumentException("Task ID not found");

		}

// saves updated description 
task.setDescription(description);

	}

// returns task 
public Task getTask(String taskId) { 

return tasks.get(taskId); 

}
}