package taskservice;
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 


//TaskTest.java 
//Author: Marisol Muniz  
//Tests the Task class. 
//Makes sure task requirements are working. 


public class TaskTest { 



//Creates a task and checks the values. 
@Test 

public void testTaskCreation() { 

Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

assertEquals("12345", task.getTaskId()); 

assertEquals("Homework", task.getName()); 

assertEquals("Finish CS 320 assignment", task.getDescription()); 

} 


//Tests empty task ID. 
@Test 

public void testTaskIdCannotBeNull() { 

assertThrows(IllegalArgumentException.class, () -> { 

new Task(null, "Homework", "Finish CS 320 assignment"); 

}); 

} 


//Tests too long task ID. 
@Test 

public void testTaskIdCannotBeLongerThanTenCharacters() { 

assertThrows(IllegalArgumentException.class, () -> { 

new Task("12345678901", "Homework", "Finish CS 320 assignment"); 

}); 

} 


//Tests empty task name. 
@Test 

public void testTaskNameCannotBeNull() { 

assertThrows(IllegalArgumentException.class, () -> { 

new Task("12345", null, "Finish CS 320 assignment"); 

}); 

} 


//Tests too long task name. 
@Test 

public void testTaskNameCannotBeLongerThanTwentyCharacters() { 

assertThrows(IllegalArgumentException.class, () -> { 

 new Task("12345", "ThisTaskNameIsWayTooLong", "Finish CS 320 assignment"); 

}); 

} 


//Tests empty description. 
@Test 

public void testDescriptionCannotBeNull() { 

assertThrows(IllegalArgumentException.class, () -> { 

new Task("12345", "Homework", null); 

}); 

} 


//Tests too long description. 
public void testDescriptionCannotBeLongerThanFiftyCharacters() { 

assertThrows(IllegalArgumentException.class, () -> { 

new Task( 

"12345", 

"Homework", 

"This description is intentionally longer than fifty characters to fail." 

); 

}); 

} 


//Updates task information. 
@Test 

public void testTaskSetters() { 

Task task = new Task("12345", "Homework", "Finish CS 320 assignment"); 

task.setName("Project"); 

task.setDescription("Complete Project One"); 

assertEquals("Project", task.getName()); 

assertEquals("Complete Project One", task.getDescription()); 

} 

} 
