package taskservice;


//Task.java 
//Author: Marisol Muniz 
//CS 320 Module Four Milestone 
//This class sets up on task. 
//It stores the task ID, name, and description. 


public class Task { 

//declare class 
//what's in the class: task ID, name, description 
private final String taskId; 
private String name; 
private String description; 


//creates a new task 
public Task(String taskId, String name, String description) { 

	
//set limits on task ID 
if (taskId == null || taskId.length() > 10) { 

throw new IllegalArgumentException("Invalid task ID"); 

} 

//set limits on task name 
if (name == null || name.length() > 20) { 

throw new IllegalArgumentException("Invalid task name"); 

} 

//set limits on description 
if (description == null || description.length() > 50) { 

throw new IllegalArgumentException("Invalid description"); 

} 


//save when correct 
this.taskId = taskId; 

this.name = name; 

this.description = description; 

} 


//shows results 
public String getTaskId() { 

return taskId; 

} 

public String getName() { 

return name; 

} 

public String getDescription() { 

return description; 

} 


//update name 
public void setName(String name) { 

if (name == null || name.length() > 20) { 

throw new IllegalArgumentException("Invalid task name"); 

} 

this.name = name; 

} 


//update description 
public void setDescription(String description) { 

if (description == null || description.length() > 50) { 

throw new IllegalArgumentException("Invalid description"); 

} 

this.description = description; 

} 

} 