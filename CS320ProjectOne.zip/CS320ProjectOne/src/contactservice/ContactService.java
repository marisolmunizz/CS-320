package contactservice; 

// ContactService.java 
// Author: Marisol Muniz 
// Stores contacts.  


//adds, deletes, and updates contacts. 
import java.util.HashMap; 
import java.util.Map; 
public class ContactService { 

 
// Stores all contacts. 
//contact ID is the key. 
//Contact object is the value. 
private Map<String, Contact> contacts = new HashMap<>(); 

 
// Adds a new contact. 
public void addContact(Contact contact) { 

 
// Makes sure contact is not empty. 
if (contact == null) { 
throw new IllegalArgumentException("Contact cannot be null"); 
} 


// Get contact ID. 
String contactId = contact.getContactId(); 
 

// Checks for  duplicate ID. 
if (contacts.containsKey(contactId)) { 
throw new IllegalArgumentException("Contact ID already exists"); 
} 

 
// Saves contact. 
contacts.put(contactId, contact); 
} 

 
// Deletes contact. 
public void deleteContact(String contactId) { 


// Makes sure contact exists. 
if (!contacts.containsKey(contactId)) { 
throw new IllegalArgumentException("Contact ID not found"); 
} 

 
// Removes contact. 
      contacts.remove(contactId); 
  } 


// Updates first name. 
public void updateFirstName(String contactId, String firstName) { 
Contact contact = contacts.get(contactId); 

 
// Makes sure contact exists. 
if (contact == null) { 
throw new IllegalArgumentException("Contact ID not found"); 
} 

 
// Saves new first name. 
contact.setFirstName(firstName); 
} 

 
// Updates last name. 
public void updateLastName(String contactId, String lastName) { 
Contact contact = contacts.get(contactId); 

 
// Makes sure contact exists. 
if (contact == null) { 
throw new IllegalArgumentException("Contact ID not found"); 
} 

 
// Saves new last name. 
contact.setLastName(lastName); 
} 

 
// Updates phone number. 
public void updatePhone(String contactId, String phone) { 
Contact contact = contacts.get(contactId); 

 
// Makes sure contact exists. 
if (contact == null) { 
throw new IllegalArgumentException("Contact ID not found"); 
} 


// Saves new phone number. 
contact.setPhone(phone); 
} 


// Updates address. 
 public void updateAddress(String contactId, String address) { 
Contact contact = contacts.get(contactId); 

 
// Makes sure contact exists. 
if (contact == null) { 
throw new IllegalArgumentException("Contact ID not found"); 
} 

 
// Saves new address. 
contact.setAddress(address); 
} 


// Returns contact. 
 public Contact getContact(String contactId) { 
return contacts.get(contactId); 

  } 

} 
