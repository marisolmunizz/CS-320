package contactservice; 


// Contact.java 
// Author: Marisol Muniz 
// Creates a contact. 

// Stores the contact information. 
public class Contact { 

 
// Stores the contact ID. 
// The ID cannot be changed. 
private final String contactId; 

 
// Stores the contact information. 
private String firstName; 
private String lastName; 
private String phone; 
private String address; 

 
// Creates a new contact. 
public Contact(String contactId, String firstName, String lastName, 
String phone, String address) { 
 

// Checks the contact ID. 
if (contactId == null || contactId.length() > 10) { 
throw new IllegalArgumentException("Invalid contact ID"); 
} 

 
// Checks the first name. 
if (firstName == null || firstName.length() > 10) { 
throw new IllegalArgumentException("Invalid first name"); 
} 


// Checks the last name. 
if (lastName == null || lastName.length() > 10) { 
throw new IllegalArgumentException("Invalid last name"); 
} 

 
// Checks the phone number. 
if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) { 
throw new IllegalArgumentException("Invalid phone number"); 
} 

 
// Checks the address. 
if (address == null || address.length() > 30) { 
throw new IllegalArgumentException("Invalid address"); 
} 


// Saves the contact information. 
this.contactId = contactId; 
this.firstName = firstName; 
this.lastName = lastName; 
this.phone = phone; 
this.address = address; 
} 

 
// Returns the contact ID. 
public String getContactId() { 
return contactId; 
} 
 

// Returns the first name. 
public String getFirstName() { 
return firstName; 
} 

 
// Returns the last name. 
public String getLastName() { 
return lastName; 
} 

 
// Returns the phone number. 
public String getPhone() { 
return phone; 
} 


// Returns the address. 
public String getAddress() { 
return address; 
} 

 
// Updates the first name. 
public void setFirstName(String firstName) { 

 
// Checks the first name. 
if (firstName == null || firstName.length() > 10) { 
throw new IllegalArgumentException("Invalid first name"); 
} 

this.firstName = firstName; 
} 
 

// Updates the last name. 
public void setLastName(String lastName) { 

 
// Checks the last name. 
if (lastName == null || lastName.length() > 10) { 
throw new IllegalArgumentException("Invalid last name"); 
} 

this.lastName = lastName; 
  } 


// Updates the phone number. 
public void setPhone(String phone) { 
 

// Checks the phone number. 
if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) { 
throw new IllegalArgumentException("Invalid phone number"); 
} 

this.phone = phone; 
  } 

 
// Updates the address. 
public void setAddress(String address) { 


// Checks the address. 
if (address == null || address.length() > 30) { 
throw new IllegalArgumentException("Invalid address"); 
} 

this.address = address; 

  } 

} 
