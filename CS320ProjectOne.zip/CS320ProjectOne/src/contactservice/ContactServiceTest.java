package contactservice;


//ContactServiceTest.java
//Author: Marisol Muniz 
//Tests the ContactService class. 


//Makes sure contacts can be added, deleted, and updated. 
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 
public class ContactServiceTest { 


// Adds a contact and checks that it was saved. 
  @Test 
  public void testAddContact() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      assertEquals(contact, service.getContact("12345")); 
  } 

 
// Tests a duplicate contact ID. 
  @Test 
  public void testAddDuplicateContactId() { 
      ContactService service = new ContactService(); 
      Contact contact1 = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      Contact contact2 = new Contact("12345", "Jane", "Doe", "0987654321", "456 Oak St"); 
      service.addContact(contact1); 
      assertThrows(IllegalArgumentException.class, () -> { 
          service.addContact(contact2); 
      }); 
  } 

 
// Deletes a contact and checks that it was removed. 
 @Test 
  public void testDeleteContact() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      service.deleteContact("12345");
      assertNull(service.getContact("12345")); 
  } 

 

// Tests deleting a contact that does not exist. 
  @Test 
  public void testDeleteContactNotFound() { 
      ContactService service = new ContactService(); 
      assertThrows(IllegalArgumentException.class, () -> { 
          service.deleteContact("99999"); 
      }); 
  } 

 
// Updates the first name. 
  @Test 
  public void testUpdateFirstName() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      service.updateFirstName("12345", "Jane"); 
      assertEquals("Jane", service.getContact("12345").getFirstName()); 
  } 

 
// Updates the last name. 
  @Test 
  public void testUpdateLastName() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      service.updateLastName("12345", "Doe"); 
      assertEquals("Doe", service.getContact("12345").getLastName()); 
  } 

 
// Updates the phone number. 
  @Test 
  public void testUpdatePhone() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      service.updatePhone("12345", "0987654321");
      assertEquals("0987654321", service.getContact("12345").getPhone()); 
  } 

 
// Updates the address. 
  @Test 
  public void testUpdateAddress() { 
      ContactService service = new ContactService(); 
      Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
      service.addContact(contact); 
      service.updateAddress("12345", "456 Oak St"); 
      assertEquals("456 Oak St", service.getContact("12345").getAddress()); 
  } 


// Tests updating a contact that does not exist. 
  @Test 
  public void testUpdateContactNotFound() { 
      ContactService service = new ContactService(); 
      assertThrows(IllegalArgumentException.class, () -> { 
          service.updateFirstName("99999", "Jane"); 

      }); 

  } 

} 