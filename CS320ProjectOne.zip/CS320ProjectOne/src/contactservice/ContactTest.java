package contactservice; 


// ContactTest.java 
// Author: Marisol Muniz 
// Tests the Contact class. 


// Makes sure the contact follows the requirements. 
import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 
public class ContactTest { 

 
// Creates a contact and checks the values. 
@Test 
public void testContactCreation() { 
Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
assertEquals("12345", contact.getContactId()); 
assertEquals("John", contact.getFirstName()); 
assertEquals("Smith", contact.getLastName()); 
assertEquals("1234567890", contact.getPhone()); 
assertEquals("123 Main St", contact.getAddress()); 
} 

 
// Tests a null contact ID. 
@Test 
public void testContactIdCannotBeNull() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact(null, "John", "Smith", "1234567890", "123 Main St"); 
	  }); 
  } 

 
// Tests a contact ID that is too long. 
@Test 
public void testContactIdCannotBeLongerThanTenCharacters() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345678901", "John", "Smith", "1234567890", "123 Main St"); 
	  }); 
  } 

 
// Tests a null first name. 
@Test 
public void testFirstNameCannotBeNull() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", null, "Smith", "1234567890", "123 Main St"); 
	  }); 
  } 


// Tests a first name that is too long. 
@Test 
public void testFirstNameCannotBeLongerThanTenCharacters() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "Christopher", "Smith", "1234567890", "123 Main St"); 
	  });
  } 


// Tests a null last name. 
@Test 
public void testLastNameCannotBeNull() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", null, "1234567890", "123 Main St"); 
	  }); 
  } 


// Tests a last name that is too long. 
@Test 
public void testLastNameCannotBeLongerThanTenCharacters() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", "Washingtons", "1234567890", "123 Main St"); 
	  }); 
  } 

 
// Tests a null phone number. 
@Test 
public void testPhoneCannotBeNull() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", "Smith", null, "123 Main St"); 
	  }); 
} 


// Tests a phone number that is not 10 digits. 
@Test 
public void testPhoneMustBeTenDigits() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", "Smith", "12345", "123 Main St"); 
	  }); 
 } 
 

// Tests a phone number with letters. 
@Test 
public void testPhoneMustOnlyContainDigits() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", "Smith", "12345abcde", "123 Main St"); 
      }); 
  } 

 

// Tests a null address. 

 

  @Test 

  public void testAddressCannotBeNull() { 

      assertThrows(IllegalArgumentException.class, () -> { 

          new Contact("12345", "John", "Smith", "1234567890", null); 

      }); 

  } 


// Tests an address that is too long. 
@Test 
public void testAddressCannotBeLongerThanThirtyCharacters() { 
assertThrows(IllegalArgumentException.class, () -> { 
new Contact("12345", "John", "Smith", "1234567890", 
"1234567890123456789012345678901"); 
      }); 

  } 

 
// Updates the contact information. 
@Test 
public void testContactSetters() { 
Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St"); 
contact.setFirstName("Jane"); 
contact.setLastName("Doe"); 
contact.setPhone("0987654321"); 
contact.setAddress("456 Oak St"); 
assertEquals("Jane", contact.getFirstName()); 
assertEquals("Doe", contact.getLastName()); 
assertEquals("0987654321", contact.getPhone()); 
assertEquals("456 Oak St", contact.getAddress()); 
  } 
} 

 